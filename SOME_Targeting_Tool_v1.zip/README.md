# SOME Targeting Chrome Extension
Returns a string representing a target reference for active DOM elements designed for hijacking a method execution in a SOME attack.

<div style="justify-content: center">
    <img src="https://lh3.googleusercontent.com/3Cu4kxlR3yha8-tTlO4sTU_e5cmVyz1QZPgbZiLXrOgTtiiU57jc0SJQkxjetBRjlY080ZRpWOyhoA9-Q-SSZuB29Q=s1280-w1280-h800" width="600"> </img>
</div>


Downlad via Chrome Webstore:

https://chrome.google.com/webstore/detail/same-origin-method-execut/fkkjcdngcdcdgebgpkfanbckgkkpgkhb
